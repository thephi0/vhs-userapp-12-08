export {default as UHome} from './screens/Home';
// export {default as UBottomtab} from './screens/UBottomtab';
export {default as Splashscreen} from './screens/Splashscreen';

export {default as Successpage} from './screens/Successpage';
export {default as Repairing} from './screens/Repairing';
export {default as ESpage} from './screens/ESpage';

export {default as Enquirydetails} from './screens/Enquirydetails';
export {default as Editprofile} from './screens/Editprofile';
export {default as Mybooking} from './screens/Mybooking';

export {default as Privacy} from './screens/Privacy';
export {default as Terms} from './screens/Terms';
export {default as Refundpolicy} from './screens/Refundpolicy';

export {default as Review} from './screens/Review';
export {default as Delete} from './screens/Delete';
export {default as Help} from './screens/Help';

export {default as LocationAccess} from './screens/LocationAccess';
export {default as Loader} from './screens/Loader';
export {default as ESuccess} from './screens/ESuccess';

export {default as Socialmedia} from './screens/Socialmedia';
export {default as Upcomingdetail} from './screens/Upcomingdetail';
export {default as Livedetail} from './screens/Livedetail';

export {default as Completedetail} from './screens/Completedetail';
export {default as Summary} from './screens/Summary';
export {default as Cart} from './screens/Cart';

export {default as Wallet} from './screens/Wallet';
export {default as Invite} from './screens/Invite';
export {default as Search} from './screens/Search';
