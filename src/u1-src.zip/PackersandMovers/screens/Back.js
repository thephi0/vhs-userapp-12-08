import {View, Text} from 'react-native';
import React from 'react';

export default function Back() {
  return (
    <View>
      <Text>Back</Text>
    </View>
  );
}
