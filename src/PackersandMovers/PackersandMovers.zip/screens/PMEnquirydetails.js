import {View, Text} from 'react-native';
import React from 'react';

export default function PMEnquirydetails() {
  return (
    <View>
      <Text>Enquirydetails</Text>
    </View>
  );
}
